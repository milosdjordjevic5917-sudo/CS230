import socket
import time
import os
from datetime import datetime

HOST = "localhost"
PORT = 5001

os.makedirs("S1", exist_ok=True)

def preuzmi_fajl():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        podaci = b""

        while True:
            deo = s.recv(4096)

            if not deo:
                break

            podaci += deo

        return podaci

while True:
    try:
        with open("data.txt", "rb") as f:
            lokalni_fajl = f.read()

        fajl_sa_servera2 = preuzmi_fajl()

        if lokalni_fajl != fajl_sa_servera2:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            ime_backup = f"data_backup_{timestamp}.txt"
            putanja = os.path.join("S1", ime_backup)

            with open(putanja, "wb") as f:
                f.write(fajl_sa_servera2)

            print(f"Razlika pronadjena. Napravljen je backup: {putanja}")
        else:
            print("Fajlovi su isti.")

    except Exception as e:
        print("Greska:", e)

    time.sleep(30)