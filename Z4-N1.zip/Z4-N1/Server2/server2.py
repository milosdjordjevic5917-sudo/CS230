import socket

HOST = "localhost"
PORT = 5001

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
    server.bind((HOST, PORT))
    server.listen()

    print("Server2 je pokrenut.")

    while True:
        veza, adresa = server.accept()

        with veza:
            print("Server1 je poslao zahtev.")

            try:
                with open("data.txt", "rb") as f:
                    podaci = f.read()

                veza.sendall(podaci)

            except FileNotFoundError:
                print("data.txt ne postoji na Server2.")