import time

def server():
    time.sleep(1)
    return "Odgovor servera"

def middleware(func):
    def wrapper():
        pocetak = time.time()

        odgovor = func()

        kraj = time.time()

        if kraj - pocetak > 2:
            return "Vreme cekanja isteklo"

        return odgovor

    return wrapper

@middleware
def zahtev():
    return server()

print(zahtev())