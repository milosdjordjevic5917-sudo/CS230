import socket

HOST = "localhost"
PORT = 5000

tekst = input("Unesite tekst do 255 karaktera: ")

if len(tekst) > 255:
    print("Greska: Tekst ne sme imati vise od 255 karaktera.")
else:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as klijent:
        try:
            klijent.connect((HOST, PORT))

            klijent.sendall(tekst.encode("utf-8"))

            hash_vrednost = klijent.recv(1024).decode("utf-8")

            print("SHA-256 hash koji je poslao server:")
            print(hash_vrednost)

        except ConnectionRefusedError:
            print("Greska: Server nije pokrenut.")