import socket
import hashlib

HOST = "localhost"
PORT = 5000

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
    server.bind((HOST, PORT))
    server.listen(1)

    print("Server je pokrenut...")
    print("Cekam klijenta...")

    veza, adresa = server.accept()

    with veza:
        print("Klijent je povezan.")

        podaci = veza.recv(1024).decode("utf-8")

        if podaci:
            hash_vrednost = hashlib.sha256(
                podaci.encode("utf-8")
            ).hexdigest()

            veza.sendall(hash_vrednost.encode("utf-8"))

            print("Primljen tekst:", podaci)
            print("SHA-256 hash:", hash_vrednost)