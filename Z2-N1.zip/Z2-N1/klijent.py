import socket
import time

HOST = "localhost"
PORT = 5000

try:
    klijent = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    klijent.connect((HOST, PORT))

    print("Uspesno povezivanje sa serverom.")
    print("Slanje OOB podataka pocinje...")

    for i in range(10, -1, -1):
        poruka = f"{i} sends remaining..."

        klijent.send(poruka.encode("utf-8"), socket.MSG_OOB)

        print("Poslato:", poruka)

        if i > 0:
            time.sleep(5)

    klijent.close()

    print("Veza sa serverom je prekinuta.")

except ConnectionRefusedError:
    print("Greska: Server nije pokrenut.")

except Exception as e:
    print("Doslo je do greske:", e)